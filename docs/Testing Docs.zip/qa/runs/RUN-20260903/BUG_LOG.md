# Bug & Issue Log — RUN-20260903

---

## Run metadata

| Field | Value |
|-------|-------|
| Run ID | RUN-20260903 |
| Tester | |
| Environment | Production |
| Tenant slug | |
| Date range | 2026-09-03 |

---

## Summary

| Severity | Open | Closed | Total |
|----------|------|--------|-------|
| Critical | 0 | 0 | 0 |
| High | 1 | 0 | 1 |
| Medium | 0 | 0 | 0 |
| Low | 0 | 0 | 0 |
| Known limitation | 0 | — | 0 |

---

## Open issues (quick list)

| ID | Severity | Module | Title | Status |
|----|----------|--------|-------|--------|
| BUG-001 | High | Admin Menu | Delete button does not remove menu category/item | Open (fix ready — retest after deploy) |

---

### BUG-001

| Field | Value |
|-------|-------|
| **ID** | BUG-001 |
| **Date found** | 2026-09-03 |
| **Reporter** | Tester (informal #9) |
| **Test case ID** | TC-1.3-01 / TC-3-04 |
| **Phase / Module** | Phase 1/3 — Admin Menu |
| **App / URL** | https://admin.cullinos.com/menu |
| **Role used** | Owner |
| **Severity** | High |
| **Type** | Bug |
| **Status** | Open (fix implemented locally — needs deploy + retest) |

#### Steps to reproduce

1. Login as restaurant owner at Admin.
2. Open **Menu**.
3. Add a category and/or menu item.
4. Click **Delete** on the category or item.

#### Expected

```
Item/category is removed from the list (or clearly marked deleted).
```

#### Actual

```
Delete appears to do nothing — row stays in the list.
Category delete can fail silently when the category still has items (FK).
```

#### Root cause

- `DELETE /menu/items/:id` soft-deletes via `isActive: false`, but `GET /menu/items` returned all rows including inactive.
- `DELETE /menu/categories/:id` hard-deleted and failed when menu items still referenced the category.
- Admin UI read `isAvailable` while API exposes `isActive`.

#### Fix (local)

- List endpoints filter `isActive: true`.
- Category delete soft-deletes category + its items.
- Admin Menu delete uses confirm + `type="button"` + error display; UI uses `isActive`.

#### Evidence

| Type | Location |
|------|----------|
| Screenshot | `runs/RUN-20260903/evidence/` (add if available) |
| Console error | |
| Network (HAR) | |

#### Workaround

```
None reliable in production until API deploy.
```

#### Retest

| Field | Value |
|-------|-------|
| Retest date | |
| Retested by | |
| Result | |
| Notes | After API + Admin deploy: create item → Delete → row must disappear. Same for category with items. |

---

## Known limitations log (not bugs)

| ID | Module | Description | Documented in plan |
|----|--------|-------------|-------------------|
| KL-001 | Admin Tables | Phase 2 placeholder UI | Yes |
| KL-002 | Admin Inventory | Phase 2 placeholder UI | Yes |
| KL-003 | POS/KDS | Web apps at pos/kds.cullinos.com (DNS required) | Yes |
| KL-004 | Razorpay | Pay-now requires keys | Yes |
