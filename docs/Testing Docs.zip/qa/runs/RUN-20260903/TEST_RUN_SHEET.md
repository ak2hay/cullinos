# Test Run Sheet — RUN-20260903

> Marked from tester reports on 2026-09-03.  
> **Pass** = expected result | **Fail** = defect (log in BUG_LOG) | **Blocked** = cannot test | **N/A** = not applicable

---

## Run header

| Field | Value |
|-------|-------|
| Run ID | RUN-20260903 |
| Tester | |
| Employee (Waiter) | |
| Tenant slug | |
| Outlet slug | |
| Date started | 2026-09-03 |
| Date completed | |

### Results summary (reported so far)

| Result | Count |
|--------|-------|
| Pass | 5+ (see Phase 5 / owner notes below) |
| Fail | 1 |
| Blocked | |
| N/A | |
| **Total cases in sheet** | 127 |

---

## Tester-reported checklist (informal #5–9)

| # | Observation | Result | Maps to |
|---|-------------|:------:|---------|
| 5 | Restaurant Owner Login successfully | Pass | TC-1.2-01, TC-4-01 |
| 6 | Suspension button works successfully | Pass | TC-5-13, TC-5-14 |
| 7 | Subscription management works successfully | Pass | TC-5-02, TC-5-03 |
| 8a | System health (platform status & operational metrics) | Pass | TC-5-04 |
| 8b | Marketing CMS loads (all tabs + lower panel) | Pass | TC-5-05 … TC-5-12 |
| 9 | Delete button not working in menu section while adding menu | **Fail** | TC-1.3-01 / TC-3-04 → **BUG-001** |

---

## Phase 5 — Super Admin platform ops (marked)

| ID | Test case | Pass | Fail | Blocked | N/A | Notes |
|----|-----------|:----:|:----:|:-------:|:---:|-------|
| TC-5-01 | QA tenant findable in tenant list | X | | | | Implied by suspend/subscription tests |
| TC-5-02 | Subscriptions — change plan for QA tenant | X | | | | #7 |
| TC-5-03 | Subscriptions — entitlements update | X | | | | #7 |
| TC-5-04 | System Health metrics load | X | | | | #8a |
| TC-5-05 | Marketing dashboard loads | X | | | | #8b |
| TC-5-06 | Marketing Hero editor saves draft | X | | | | #8b — tabs OK |
| TC-5-07 | Marketing Pages editor loads | X | | | | #8b |
| TC-5-08 | Marketing Theme editor loads | X | | | | #8b |
| TC-5-09 | Marketing Pricing editor loads | X | | | | #8b |
| TC-5-10 | Marketing Navigation editor loads | X | | | | #8b |
| TC-5-11 | Marketing Blog editor — create draft | X | | | | #8b |
| TC-5-12 | Marketing Media library loads | X | | | | #8b |
| TC-5-13 | Suspend QA tenant — owner login blocked | X | | | | #6 |
| TC-5-14 | Reactivate QA tenant — owner login works | X | | | | #5/#6 |

---

## Related owner / menu cases

| ID | Test case | Pass | Fail | Blocked | N/A | Notes |
|----|-----------|:----:|:----:|:-------:|:---:|-------|
| TC-1.2-01 | Owner login at admin.cullinos.com succeeds | X | | | | #5 |
| TC-1.3-01 | Create category 1 in Menu | | X | | | Delete broken while managing menu — BUG-001 |
| TC-3-04 | Menu — create new item | | X | | | Delete after add does not remove — BUG-001 |

---

## Fail / Blocked summary

| Test ID | Bug ID | Reason |
|---------|--------|--------|
| TC-1.3-01 / TC-3-04 | BUG-001 | Delete in Admin → Menu does not remove category/item from UI |

---

## Sign-off

| Field | Value |
|-------|-------|
| All Critical/High failures logged in BUG_LOG | Y |
| Credentials Log completed (no passwords in git) | |
| Known limitations separated from open bugs | Y |
| Tester signature | |
| Reviewer signature | |
| Sign-off date | |

### Comments

```
Informal results #5–9 recorded 2026-09-03.
BUG-001 root cause: soft-delete set isActive=false but list endpoints returned inactive rows;
category hard-delete failed when items still referenced the category.
Fix applied in API + Admin Menu page (pending deploy/retest).
```
